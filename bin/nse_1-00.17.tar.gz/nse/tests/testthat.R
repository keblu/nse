library(testthat)
library(nse)

test_check("nse")
